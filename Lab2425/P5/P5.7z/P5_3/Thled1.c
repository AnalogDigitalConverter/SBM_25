#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "stm32f4xx_hal.h"



#define Led2 0x01
#define Led3 0x02
/*----------------------------------------------------------------------------
 *      Thread 1 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/
 
osThreadId_t tid_Thled1;                        // thread id
osEventFlagsId_t Ciclos_evt_f_id;									// Event flag 
extern osThreadId_t tid_Thled2;


static void Thled1(void *argument);
static void Led_init(void);

 
int Init_Thled1 (void) {
 tid_Thled1 = osThreadNew(Thled1, NULL, NULL);
  if (tid_Thled1 == NULL) {
    return(-1);
  }
  return(0);
}


static void Thled1 (void *argument) {
	Led_init();
	int cnt_1 = 0;
  while (1) {
 // Insert thread code here...
		if (cnt_1 < 6)	 
			cnt_1++;
		
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
		osDelay(200);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
		osDelay(800);
		

		
		if (cnt_1 == 5) 
			{
				osThreadFlagsSet(tid_Thled2, Led2);
			}
  }
}

static void Led_init(void){
	  GPIO_InitTypeDef GPIO_InitStruct;
  __HAL_RCC_GPIOB_CLK_ENABLE();
  
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
}

