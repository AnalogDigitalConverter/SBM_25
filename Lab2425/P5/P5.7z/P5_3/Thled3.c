#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "stm32f4xx_hal.h"


#define Led2 0x00000001U
#define Led3 0x00000004U

/*----------------------------------------------------------------------------
 *      Thread 1 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/
 
osThreadId_t tid_Thled3;                        // thread id
extern osEventFlagsId_t Ciclos_evt_f_id;
extern osThreadId_t tid_Thled2;


static void Thled3(void *argument);
static void Led3_init(void);
int Init_Thled3(void);
 
int Init_Thled3 (void) {
		 tid_Thled3 = osThreadNew(Thled3, NULL, NULL);
			if (tid_Thled3 == NULL) {
				return(-1);
			}
		return(0);
	
}
 
static void Thled3 (void *argument) {
	int cnt_3; 

	Led3_init();
	
	osThreadFlagsWait(Led3, osFlagsWaitAll, osWaitForever);

	cnt_3 = 0;
		while (1) {
			// Insert thread code here...
			cnt_3++;
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
			osDelay(287);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
			osDelay(287);
			
			if (cnt_3 == 25){
				osThreadFlagsSet(tid_Thled2, Led2);
			}
			else if (cnt_3 == 30){
				cnt_3 = 0;
				osThreadFlagsWait(Led3, osFlagsWaitAll, osWaitForever);
			}
		}
	
}

static void Led3_init(void){
	GPIO_InitTypeDef GPIO_InitStruct;
	__HAL_RCC_GPIOB_CLK_ENABLE();

	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;

	GPIO_InitStruct.Pin = GPIO_PIN_14;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);

}

