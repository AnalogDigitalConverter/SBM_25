#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "stm32f4xx_hal.h"


#define Led2 0x00000001U
#define Led3 0x00000004U
/*----------------------------------------------------------------------------
 *      Thread 1 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/
 
osThreadId_t tid_Thled2;                        // thread id
extern osEventFlagsId_t Ciclos_evt_f_id;
extern osThreadId_t tid_Thled3;


static void Thled2(void *argument);
static void Led2_init(void);
int Init_Thled2 (void);
 
int Init_Thled2 (void) {
			tid_Thled2 = osThreadNew(Thled2, NULL, NULL);
			if (tid_Thled2 == NULL) {
				return(-1);
		}
 
  return(0);
}
 
static void Thled2 (void *argument) {
	
	int cnt_2;
	Led2_init();
	
	osThreadFlagsWait(Led2, osFlagsWaitAll, osWaitForever);
	
		cnt_2 = 0;
		while (1) {
	 // Insert thread code here...
			cnt_2++;
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
			osDelay(137);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
			osDelay(137);
			
			if (cnt_2 == 15){
				osThreadFlagsSet(tid_Thled3, Led3);
			}
			else if (cnt_2 == 20){
				cnt_2 = 0;
				osThreadFlagsWait(Led2, osFlagsWaitAll, osWaitForever);
			}
		}
	
}

static void Led2_init(void){
	  GPIO_InitTypeDef GPIO_InitStruct;
  __HAL_RCC_GPIOB_CLK_ENABLE();
  
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);

}

