#ifndef LCD_H
#define LCD_H

#include "Driver_SPI.h"  
#include "main.h"
#include "stdio.h"
#include "string.h"

void LCD_init(void);
void Display_Text_Update(char text_L1[32], char text_L2[32]);

#endif
